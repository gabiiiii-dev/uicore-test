//assets
import Arrow from "../assets/arrow.svg";
import Close from "../assets/close.svg";

//utilities
import { useEffect, useState } from "react";
import {
	DocumentData,
	addDoc,
	collection,
	doc,
	getDoc,
} from "firebase/firestore";
import database from "../firebase/firebaseConfig";
import { databaseCollections } from "../firebase/databaseCollections";

//components
import Loading from "../components/loading";
import Error from "../components/error";

export default function Form() {
	const [options, setOptions] = useState<DocumentData>();
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(false);

	interface FormData {
		name: string;
		accesMode: string;
		purpose: string;
		mode: string;
		refference: string;
		chatLimit: number;
		contextSize: string;
		sources: Array<string>;
	}

	const [formData, setFormData] = useState<FormData>({
		name: "",
		accesMode: "Public",
		purpose: "Support Agent",
		mode: "Chat",
		refference: "Include as Link",
		chatLimit: 10,
		contextSize: "Small",
		sources: ["Source"],
	});

	//Loading the options for the form on initial page load
	useEffect(() => {
		getDoc(
			doc(database, databaseCollections.formOptions, "uL9u0LH5hkK5ZIYaBo0Q")
		)
			.then((data) => {
				setOptions(data.data());
				setLoading(false);
			})
			.catch(() => {
				setLoading(false);
				setError(true);
			});

		console.log(formData);
	}, []);

	return (
		<div className="bg-body-color m-0 h-screen w-screen flex justify-center items-center font-satoshi ">
			<div className="h-form-height w-form-width bg-white rounded-form-radius border-form-color border-form-width shadow-form overflow-hidden">
				{loading ? (
					<Loading />
				) : error ? (
					<Error />
				) : options ? (
					<>
						<div className="h-header-height border-b-form-width border-b-form-color pr-form-padding pl-form-padding flex justify-between items-center">
							<p className="font-regular text-16">General</p>
							<button
								className="w-btn-width h-btn-height bg-btn-color text-white text-16 font-regular rounded-btn-radius"
								onClick={() => {
									if (
										!formData.name ||
										!formData.accesMode ||
										!formData.purpose ||
										!formData.mode ||
										!formData.refference ||
										!formData.chatLimit ||
										!formData.contextSize ||
										formData.sources.length == 0
									) {
										alert("Please fill in all the information");
									} else {
										alert("Your informations are sending...!");

										addDoc(
											collection(
												database,
												databaseCollections.formResponses
											),
											formData
										)
											.then(() => {
												alert(
													"Your informations were succesfully sent!"
												);
											})
											.catch(() => {
												alert(
													"Your informatiosn were not sent, please try again later"
												);
											});
									}
								}}
							>
								Save
							</button>
						</div>
						<div className="grid grid-cols-2 pr-form-padding pl-form-padding gap-form-gap mt-form-top font-regular">
							<div className="col-span-2 flex flex-col">
								<label
									htmlFor="name"
									className="text-14 mb-label-bottom"
								>
									Name
								</label>
								<input
									type="text"
									name="name"
									className="text-ellipsis text-input-color w-full text-16 pl-input-x-padding pt-input-y-padding pb-input-y-padding border-form-color border-input-width rounded-input-radius outline-blue font-light"
									placeholder="Enter your name..."
									autoFocus
									onChange={(e) => {
										setFormData({
											...formData,
											name: e.target.value,
										});
									}}
								/>
							</div>
							<div className="flex flex-col relative">
								<label
									htmlFor="acces-mode"
									className="text-14 mb-label-bottom"
								>
									Acces
								</label>
								<Arrow className="z-10 cursor-pointer absolute bottom-arrow-bottom-pos right-arrow-right-pos" />
								<select
									name="acces-mode"
									defaultValue={options.accesMode[0]}
									onChange={(e) => {
										setFormData({
											...formData,
											accesMode: e.target.value,
										});
									}}
									className=" text-ellipsis font-light bg-transparent z-20 cursor-pointer text-input-color appearance-none w-full text-16 pl-input-x-padding pr-input-right-padding pt-input-y-padding pb-input-y-padding border-form-color border-input-width rounded-input-radius outline-blue"
								>
									{options.accesMode.map((type: any) => {
										return (
											<option value={type} key={type}>
												{type}
											</option>
										);
									})}
								</select>
							</div>
							<div className="flex flex-col relative">
								<label
									htmlFor="purpose"
									className="text-14 mb-label-bottom"
								>
									Purpose
								</label>
								<Arrow className="z-10 cursor-pointer absolute bottom-arrow-bottom-pos right-arrow-right-pos" />

								<select
									name="purpose"
									defaultValue={options.purpose[0]}
									onChange={(e) => {
										setFormData({
											...formData,
											purpose: e.target.value,
										});
									}}
									className="text-ellipsis font-light bg-transparent z-20 cursor-pointer text-input-color appearance-none w-full text-16 pl-input-x-padding pr-input-right-padding pt-input-y-padding pb-input-y-padding border-form-color border-input-width rounded-input-radius outline-blue"
								>
									{options.purpose.map((type: any) => {
										return (
											<option value={type} key={type}>
												{type}
											</option>
										);
									})}
								</select>
							</div>
							<div className="flex flex-col relative">
								<label
									htmlFor="mode"
									className="text-ellipsis text-14 mb-label-bottom"
								>
									Mode
								</label>
								<Arrow className="z-10 cursor-pointer absolute bottom-arrow-bottom-pos right-arrow-right-pos" />

								<select
									name="mode"
									defaultValue={options.mode[0]}
									onChange={(e) => {
										setFormData({
											...formData,
											mode: e.target.value,
										});
									}}
									className="text-ellipsis font-light bg-transparent z-20 cursor-pointer text-input-color appearance-none w-full text-16 pl-input-x-padding pr-input-right-padding pt-input-y-padding pb-input-y-padding border-form-color border-input-width rounded-input-radius outline-blue"
								>
									{options.mode.map((type: any) => {
										return (
											<option value={type} key={type}>
												{type}
											</option>
										);
									})}
								</select>
							</div>
							<div className="flex flex-col relative">
								<label
									htmlFor="refference"
									className="text-14 mb-label-bottom"
								>
									Refference
								</label>
								<Arrow className="z-10 cursor-pointer absolute bottom-arrow-bottom-pos right-arrow-right-pos" />

								<select
									name="refference"
									defaultValue={options.refference[0]}
									onChange={(e) => {
										setFormData({
											...formData,
											refference: e.target.value,
										});
									}}
									className="text-ellipsis font-light bg-transparent z-20 cursor-pointer text-input-color appearance-none w-full text-16 pl-input-x-padding pr-input-right-padding pt-input-y-padding pb-input-y-padding border-form-color border-input-width rounded-input-radius outline-blue"
								>
									{options.refference.map((type: any) => {
										return (
											<option value={type} key={type}>
												{type}
											</option>
										);
									})}
								</select>
							</div>
							<div className="flex flex-col">
								<label
									htmlFor="chat-limit"
									className=" text-14 mb-label-bottom"
								>
									Limit chat to x messages
								</label>
								<input
									type="number"
									name="chat-limit"
									min={0}
									defaultValue={10}
									onChange={(e) => {
										setFormData({
											...formData,
											chatLimit: parseInt(e.target.value),
										});
									}}
									className="text-ellipsis font-light text-input-color w-full text-16 pl-input-x-padding pt-input-y-padding pb-input-y-padding border-form-color border-input-width rounded-input-radius outline-blue"
								/>{" "}
							</div>
							<div className="flex flex-col relative">
								<label
									htmlFor="context-size"
									className="text-14 mb-label-bottom"
								>
									Context Size
								</label>
								<Arrow className="z-10 cursor-pointer absolute bottom-arrow-bottom-pos right-arrow-right-pos" />

								<select
									name="context-size"
									defaultValue={options.contextSize[0]}
									onChange={(e) => {
										setFormData({
											...formData,
											contextSize: e.target.value,
										});
									}}
									className="text-ellipsis font-light bg-transparent z-20 cursor-pointer text-input-color appearance-none w-full text-16 pl-input-x-padding pr-input-right-padding pt-input-y-padding pb-input-y-padding border-form-color border-input-width rounded-input-radius outline-blue"
								>
									{options.contextSize.map((type: any) => {
										return (
											<option value={type} key={type}>
												{type}
											</option>
										);
									})}
								</select>
							</div>
							<div className="flex flex-col col-span-2 relative">
								<label
									htmlFor="sources"
									className="text-14 mb-label-bottom"
								>
									Sources
								</label>
								<Arrow className="z-20 cursor-pointer absolute bottom-arrow-bottom-pos right-arrow-right-pos" />
								<div className="flex flex-row h-input-height bg-transparent z-20 text-input-color appearance-none w-full text-16 pt-source-wrapper-y-padding pb-source-wrapper-y-padding border-form-color border-input-width rounded-input-radius outline-blue">
									<div className=" w-sources-scroll-area flex flex-row overflow-hidden">
										{formData.sources ? (
											formData.sources.map((source) => {
												return (
													<>
														<div
															key={source}
															className="whitespace-no-wrap ml-source-left-margin h-full bg-source-bg-color flex flex-nowrap items-center bg-blue-600 relative pl-source-left-padding pr-source-right-padding border-source-width border-form-color rounded-source-radius outline-blue"
														>
															<p className="text-ellipsis font-regular mr-source-text-right-margin text-text-color">
																{source}
															</p>
															<Close
																className="cursor-pointer"
																onClick={() =>
																	setFormData({
																		...formData,
																		sources:
																			formData.sources.filter(
																				(element) =>
																					element !==
																					source
																			),
																	})
																}
															/>
														</div>
													</>
												);
											})
										) : (
											<h1>da</h1>
										)}
									</div>
									<input
										placeholder="Select Source..."
										type="search"
										list="sources"
										onKeyDown={(e: any) => {
											if (e.key == "Enter") {
												!formData.sources.includes(e.target.value)
													? setFormData({
															...formData,
															sources: [
																...formData.sources,
																e.target.value,
															],
													  })
													: () => {};
											}
										}}
										className=" border-b-form-width border-b-form-color w-sources-search bg-transparent ml-source-left-margin mr-source-left-margin text-black text-light z-10 relative outline-none pl-source-left-padding pr-source-right-padding "
									/>

									<datalist id="sources">
										{options.sources.map((source: any) => {
											return (
												<option
													value={source}
													key={source}
												></option>
											);
										})}
									</datalist>
								</div>
							</div>
						</div>
					</>
				) : (
					<></>
				)}
			</div>
		</div>
	);
}
