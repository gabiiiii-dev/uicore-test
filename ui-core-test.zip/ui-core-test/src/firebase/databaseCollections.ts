export const databaseCollections = {
	formOptions: "form-options",
	formResponses: "form-responses",
};
