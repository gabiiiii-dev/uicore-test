import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
	apiKey: "AIzaSyCQMKUYSQ6seE-D-SuorrdqFfss2MBPW_w",
	authDomain: "uicore-test-8a33a.firebaseapp.com",
	projectId: "uicore-test-8a33a",
	storageBucket: "uicore-test-8a33a.appspot.com",
	messagingSenderId: "339790679362",
	appId: "1:339790679362:web:5fb9e5a083f998cc878cdb",
};

const app = initializeApp(firebaseConfig);
const database = getFirestore(app);

export default database;
