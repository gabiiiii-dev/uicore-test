export default function Error() {
	return (
		<div className="flex justify-center items-center w-full h-full bg-btn-color">
			<h1 className="text-white font-satoshi font-regular">
				We are sorry, the data could not be fetched
			</h1>
		</div>
	);
}
