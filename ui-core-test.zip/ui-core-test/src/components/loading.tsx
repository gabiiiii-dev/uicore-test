import styles from "../styles/loading.module.css";

export default function Loading() {
	return (
		<div className="flex justify-center items-center w-full h-full bg-btn-color">
			<div className={styles.spinner}>
				<div></div>
				<div></div>
				<div></div>
				<div></div>
			</div>
		</div>
	);
}
