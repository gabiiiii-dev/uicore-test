/** @type {import('tailwindcss').Config} */
module.exports = {
	content: ["./src/**/*.{js,ts,jsx,tsx}"],
	theme: {
		extend: {
			fontFamily: {
				satoshi: "'Satoshi', sans-serif",
			},
			fontWeight: {
				light: "400",
				regular: "500",
			},
			fontSize: {
				16: "16px",
				14: "14px",
			},
			colors: {
				"body-color": "#F1F5F9",
				"btn-color": "#3C50E0",
				"input-color": "#64748B",
				"source-bg-color": "#EFF4FB",
				"text-color": "#637381",
			},
			width: {
				"form-width": "475px",
				"btn-width": "84px",
				"sources-scroll-area": "55%",
				"sources-search": "45%",
			},
			height: {
				"form-height": "602px",
				"header-height": "58px",
				"btn-height": "40px",
				"input-height": "50px",
			},
			borderRadius: {
				"form-radius": "2px",
				"btn-radius": "4px",
				"input-radius": "4px",
				"source-radius": "3px",
			},
			borderWidth: {
				"form-width": "1px",
				"input-width": "1.5px",
				"source-width": "0.5px",
			},
			borderColor: {
				"form-color": "#E2E8F0",
			},
			padding: {
				"form-padding": "28px",
				"input-y-padding": "13px",
				"input-x-padding": "17px",
				"input-right-padding": "40px",
				"source-x-input-x-padding": "7px",
				"source-y-padding": "8px",
				"source-left-padding": "9px",
				"source-right-padding": "11px",
				"source-wrapper-y-padding": "7px",
			},
			gap: {
				"form-gap": "20px",
			},
			margin: {
				"form-top": "13px",
				"label-bottom": "12px",
				"source-left-margin": "5px",
				"source-text-right-margin": "6.5px",
			},
			outlineColor: {
				blue: "#3056D3",
			},
			boxShadow: {
				form: "0px 8px 13px -3px rgba(0,0,0,0.07)",
			},
			spacing: {
				"arrow-right-pos": "15px",
				"arrow-bottom-pos": "21px",
			},
		},
	},
	plugins: [],
};
