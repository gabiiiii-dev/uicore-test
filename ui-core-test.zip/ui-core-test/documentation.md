# **UI Improvements**

-  Aligning the **SAVE** Button with the rest of the content and making it's text color white to ensure contrast and visibility
-  Aligning the **Chat Limit** Input with the rest of the content
-  Adding the same space between the **Sources** label and input, to ensure consistency in the design

# **UX Improvements**

-  Adding an **Loading** and an **Error** state
-  Letting the user to input his own sources of information, while providing in the same time a list of predefined sources to choose from

# **Logic and Infrastructure**

-  The form's options (that includes all the input's posibile options) are stored in a particular document in the firestore database named "form-options". This way, the administrator can easily add or delete certain options, ensuring scalability. In addition to this, I added an Loading and Error states, to ensure a better interaction with the form.
-  The information in the form is not sent if the user does not fill all the inputs. ( _I assumed this, even if in the design, there are not any refferences that the inputs are mandatory_ )
-  For the _"Sending.."_, _"Succesfully Sent"_ and _"Input not filled"_ states, I just added a few alerts.
